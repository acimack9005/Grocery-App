//
//  MapViewController.swift
//  MyApp
//
//  Created by apcsp on 9/23/16.
//  Copyright © 2016 apcsp. All rights reserved.
//

import UIKit

class MapViewController: UIViewController
{

    @IBOutlet weak var marianos: UIImageView!
    override func viewDidLoad()
    {
        super.viewDidLoad()

     marianos.image = UIImage(named: "marianos")
    }
    

}
