//
//  Item.swift
//  MyApp
//
//  Created by apcsp on 9/21/16.
//  Copyright © 2016 apcsp. All rights reserved.
//

import UIKit

class Item: NSObject
{

        var name: String
        var amount: String
        var location: String
    //  var list: String
    
    init(Name n: String, Amount a: String, Location l: String)
        {
            name = n
            amount = a
            location = l
         //   list = i
            
        }
        
        
}


