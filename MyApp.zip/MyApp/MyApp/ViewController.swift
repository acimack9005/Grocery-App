//
//  ViewController.swift
//  MyApp
//
//  Created by apcsp on 9/21/16.
//  Copyright © 2016 apcsp. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    var list = [Item]()
    
    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad()
    {
        super.viewDidLoad()
        tableView.editing = false
        navigationItem.title = "Grocery List"

    }
    
   
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        return list.count
        
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("myCell", forIndexPath: indexPath)
        cell.textLabel!.text = list[indexPath.row].name
        cell.detailTextLabel!.text = "Aisle: \(list[indexPath.row].location)"
        cell.textLabel?.font = UIFont(name: "Times New Roman", size: 30)
        cell.detailTextLabel?.font = UIFont(name: "Times New Roman", size: 20)
        
        
        return cell
        
    }
    
    var newItem = Item(Name: "Blank", Amount: "Blank", Location: "Blank")


    @IBAction func addItemButton(sender: AnyObject)
    {
        
        
        
        /////////
        
        list.append(newItem)

        
        let alert = UIAlertController(title: "What would you like to buy?", message: "", preferredStyle: .Alert)
        
        alert.addTextFieldWithConfigurationHandler({ (textField) -> Void in textField.placeholder = "Name"})
        
        alert.addTextFieldWithConfigurationHandler({ (textField) -> Void in textField.placeholder = "Location"})
        
        alert.addTextFieldWithConfigurationHandler({ (textField) -> Void in textField.placeholder = "Amount"})
        

        
        alert.addAction(UIAlertAction(title: "Cancel", style: .Default, handler: {(action) -> Void in
            
              
        }))

       
        
        alert.addAction(UIAlertAction(title: "Okay", style: .Default, handler: {(action) -> Void in
            
            let textField = alert.textFields![0] as UITextField
            self.newItem.name = (textField.text!)
            
            let textField2 = alert.textFields![1] as UITextField
            self.newItem.location = (textField2.text!)
            
            let textField3 = alert.textFields![2] as UITextField
            self.newItem.amount = (textField3.text!)
            
            
            
            self.tableView.reloadData()
        }))
        
        ////////
        
        self.presentViewController(alert, animated: true, completion: nil)
        
        

    }
    
    
    var deleteIndexPath: NSIndexPath? = nil
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath)
    {
        if editingStyle == .Delete
        {
            deleteIndexPath = indexPath
            let deletedSchool = list[indexPath.row]
            confirmDelete(deletedSchool)
        }
    }
    
    func confirmDelete(food: Item)
    {
        let alert = UIAlertController(title: "Delete Item", message: "Are you sure you want to permanently delete \(food.name)?", preferredStyle: .ActionSheet)
        
        let DeleteAction = UIAlertAction(title: "Delete", style: .Destructive, handler: handleDeleteItem)
        let CancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: cancelDeleteItem)
        
        alert.addAction(DeleteAction)
        alert.addAction(CancelAction)
        
        
        alert.popoverPresentationController?.sourceView = self.view
        alert.popoverPresentationController?.sourceRect = CGRectMake(self.view.bounds.size.width / 2.0, self.view.bounds.size.height / 2.0, 1.0, 1.0)
        
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    var deleteItemIndexPath: NSIndexPath? = nil
    
    
    func handleDeleteItem(alertAction: UIAlertAction!) -> Void
    {
        if let indexPath = deleteIndexPath
        {
            tableView.beginUpdates()
            
            list.removeAtIndex(indexPath.row)
            
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Automatic)
            
            deleteItemIndexPath = nil
            
            tableView.endUpdates()
        }
    }
    
    func cancelDeleteItem(alertAction: UIAlertAction!)
    {
        deleteItemIndexPath = nil
    }
    
    var count = 0
    
    @IBAction func editButton(sender: AnyObject)
    {
        if count == 0
        {
            tableView.editing = true
            count = 1
        }
        else
        {
            tableView.editing = false
            count = 0
        }
        
        
    }
    
    
    func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool
    {
        return true
    }
    
    
    
    func tableView(tableView: UITableView, moveRowAtIndexPath sourceIndexPath: NSIndexPath, toIndexPath destinationIndexPath: NSIndexPath)
    {
        let selectedItem = list[sourceIndexPath.row]
        list.removeAtIndex(sourceIndexPath.row)
        list.insert(selectedItem, atIndex: destinationIndexPath.row)
    }
    
//    func addNewList()
//    {
//        
//        var newList = [Item]()
//        var newListName = ""
//        
//        alert.addTextFieldWithConfigurationHandler({ (textField) -> Void in textField.placeholder = "New List Name"})
//        
//        
//       
//        alert.addAction(UIAlertAction(title: "Okay", style: .Default, handler: {(action) -> Void in
//            
//            let textField = alert.textFields![0] as UITextField
//            self.newListName = (textField.text!)
//            
//
//        
//        
//    }
//    
    

    
}
