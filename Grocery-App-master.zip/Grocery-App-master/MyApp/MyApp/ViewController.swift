//
//  ViewController.swift
//  MyApp
//
//  Created by apcsp on 9/21/16.
//  Copyright © 2016 apcsp. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    var list = [Item]()
    
    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad()
    {
        super.viewDidLoad()
        var apples = Item(Name: "Apples", Amount: "2", Location: "10")
        
        list.append(apples)
        
    }
    
    var newItem = Item(Name: "Blank", Amount: "Blank", Location: "Blank")

    @IBAction func addItemButton(sender: AnyObject)
    {
        let alert = UIAlertController(title: "What would you like to buy?", message: "", preferredStyle: .Alert)
        
        alert.addTextFieldWithConfigurationHandler({ (textField) -> Void in textField.placeholder = "Name"})
        
        alert.addTextFieldWithConfigurationHandler({ (textField) -> Void in textField.placeholder = "Location"})
        
        alert.addTextFieldWithConfigurationHandler({ (textField) -> Void in textField.placeholder = "Amount"})
        
       
        
        alert.addAction(UIAlertAction(title: "Okay", style: .Default, handler: {(action) -> Void in
            
            let textField = alert.textFields![0] as UITextField
            self.newItem.name = (textField.text!)
            
            let textField2 = alert.textFields![1] as UITextField
            self.newItem.location = (textField2.text!)
            
            let textField3 = alert.textFields![2] as UITextField
            self.newItem.amount = (textField3.text!)
            
            
            
            self.tableView.reloadData()
        }))
        
        self.presentViewController(alert, animated: true, completion: nil)
        
        

    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
    
        return 1
    
    }
   
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
    
    let cell = tableView.dequeueReusableCellWithIdentifier("myCell", forIndexPath: indexPath)
        cell.textLabel!.text = list[indexPath.row].name
        cell.detailTextLabel!.text = "Aisle: \(list[indexPath.row].location)"
        cell.textLabel?.font = UIFont(name: "Times New Roman", size: 30)
        cell.detailTextLabel?.font = UIFont(name: "Times New Roman", size: 20)
        

        return cell
    
    }
    
}
